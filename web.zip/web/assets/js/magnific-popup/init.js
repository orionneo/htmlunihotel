(function ($) {
    "use strict";

}(jQuery));